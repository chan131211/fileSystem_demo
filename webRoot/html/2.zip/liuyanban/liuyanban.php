<?php
header('content-type:text/html;charset:utf-8');
date_default_timezone_set("Asia/shanghai");
$filename="lyb.txt";
$message=[];
//检测文件是否存在
if (file_exists($filename)){
    //读取文件中的内容
    $string=file_get_contents($filename);
    if (strlen($string)>0){
        //将已序列化的字符串变回PHP的值
        $message=unserialize($string);
    }
}
//检测用户是否点击了提交按钮
if (isset($_POST['submit'])){
    //接收表单提交的数据
    $username=$_POST['username'];
    $title=$_POST['title'];
    $content=$_POST['content'];
    //获取时间
    $time = time();
    //将其组成关联数组
    $date =compact('username','title','time','content');
    array_push($message,$date);
    //将数组序列化，存储于lyb.txt文本
    $message=serialize($message);
    if (file_put_contents($filename,$message)){
       echo  "<script>alert('留言成功!');</script>";
    }else{
        echo  "<script>alert('留言失败!');</script>";
    }
}
print_r($message);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>简易留言板</title>
    <link rel="stylesheet" type="text/css" href="css/liuyanban.css">
</head>
<body>
<div class="div1">
    <div class="div2">
        <div class="div3">
            <div class="div4">
                <h1>IMOOC留言板-<span>V1.0</span></h1>
            </div>
            <div class="div4_2">
                <h1>Hello, world!</h1>
                <p class="div4_2_p1">
                    这是一个可视化布局模板, 你可以点击模板里的文字进行修改, 也可以通过点击弹出的编辑框进行富文本修改. 拖动区块能实现排序.
                </p>
                <p class="div4_2_p2">
                    <a rel="nofollow" class="" href="#">参看更多»</a>
                </p>
            </div>
            <?php if (is_array($message && count((array)$message)>0)){ ?>
            <table class="table">
                <thead>
                <tr>
                    <th>编号</th>
                    <th>用户名</th>
                    <th>标题</th>
                    <th>时间</th>
                    <th>内容</th>
                </tr>
                </thead>
                <tbody>
                <?php $i=1;foreach ($message as $val){ ?>
                <tr>
                    <td>
                        <?php echo $i++; ?>
                    </td>
                    <td>
                        <?php echo $var['username']; ?>
                    </td>
                    <td>
                        <?php echo $var['title']; ?>
                    </td>
                    <td>
                        <?php echo date("Y-m-d H:i:s",$var['time']); ?>
                    </td>
                    <td>
                        <?php echo $var['content'];?>
                    </td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
            <?php } ?>
            <form action="#" method="post">
                <label>请留言</label><hr>
                <label>用户名</label><br><input type="text" name="username" required/><br>
                <label>标题</label><br><input type="text" name="title" required><br>
                <label>内容</label><br><textarea name="content" required></textarea><br>
                <input class="form_last_input" type="submit" name="submit" value="发布留言">
            </form>
        </div>
    </div>
</div>
</body>
</html>